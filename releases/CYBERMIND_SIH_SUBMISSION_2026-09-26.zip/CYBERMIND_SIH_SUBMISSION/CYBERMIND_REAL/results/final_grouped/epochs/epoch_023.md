# Epoch 23

- Training loss: -1.928643
- Validation loss: -1.568527
- Validation precision: 0.973266
- Validation recall: 0.887957
- Validation F1: 0.928657
- Validation support: 1312 attack / 6290 benign target windows
- Selected as final best checkpoint: no

The checkpoint policy uses validation F1 with stage loss as the tie-breaker inside the configured F1 tolerance.
